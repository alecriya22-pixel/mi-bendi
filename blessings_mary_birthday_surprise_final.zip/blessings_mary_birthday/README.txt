BLESSINGS MARY — LUXURY BIRTHDAY SURPRISE

Theme: black and red luxury romance
Nickname: Mi Bendi
Song: Don't Let Go by Zavyre
Hidden message: “You are mine, and I am yours”

Preview:
1. Extract this ZIP.
2. Open index.html in Chrome or Edge.
3. Click "Listen to our song" to open the Zavyre track on Audiomack.

Personalise:
- Edit the birthday letter in index.html if you want to add your own memories.
- The three gallery cards are placeholders. Send the photos when you find them and I can place them in the site.
- Countdown is set to November 7, 2026, at midnight Kenya time (EAT).

Publish using your Firebase Hosting project:
1. Copy index.html into your Firebase project's public folder.
2. Open a terminal in the project folder.
3. Run: firebase deploy
4. Share the hosted website link with Blessings Mary.

Song link:
https://audiomack.com/zavyre/song/dont-let-go
